package cn.itcast.shopmall.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

import cn.itcast.shopmall.bean.ShopMallBean;
import cn.itcast.shopmall.utils.DBUtils;


public class SQLiteHelper extends SQLiteOpenHelper {
    private SQLiteDatabase sqLiteDatabase;
    //创建数据库
    public SQLiteHelper(Context context){
        super( context , DBUtils.DATABASE_NAME ,null , DBUtils.DATABASE_VERION );
        sqLiteDatabase = this.getWritableDatabase();
    }
    //创建表
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(" create table "+ DBUtils.DATABASE_TABLE + "(" + DBUtils.SHOPMALL_ID +
                " integer primary key autoincrement,"+ DBUtils.SHOPMALL_TITLE+
                " text ," + DBUtils.SHOPMALL_PRICE + " text , img int(30)  ) " );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }
    //添加数据
    public boolean insertData(String title,String price,int img){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DBUtils.SHOPMALL_TITLE,title);
        contentValues.put(DBUtils.SHOPMALL_PRICE,price);
        contentValues.put("img",img);
        return sqLiteDatabase.insert(DBUtils.DATABASE_TABLE,null,contentValues)>0;
    }
    //删除数据
    public boolean deleteData(String id){
        String sql =DBUtils.SHOPMALL_ID + " =? ";
        String[] contentValuesArray=new String[] {String.valueOf(id)};
        return sqLiteDatabase.delete(DBUtils.DATABASE_TABLE,sql,contentValuesArray)>0;
    }
    //删除全部数据
    public boolean deleteDataAll(){
        String sql =DBUtils.SHOPMALL_ID;
        String[] contentValuesArray=new String[] {};
        return sqLiteDatabase.delete(DBUtils.DATABASE_TABLE,sql,contentValuesArray)>0;
    }
    //查询数据
    public List<ShopMallBean> query(){
        List<ShopMallBean> list = new ArrayList<ShopMallBean>();
        Cursor cursor = sqLiteDatabase.query( DBUtils.DATABASE_TABLE ,null ,null ,null ,null ,null ,DBUtils.SHOPMALL_ID + " desc " );
        if(cursor != null){
            while(cursor.moveToNext()){
                ShopMallBean shopInfo = new ShopMallBean();
                String id = String.valueOf(cursor.getInt(cursor.getColumnIndex( DBUtils.SHOPMALL_ID )));
                String title = cursor.getString(cursor.getColumnIndex( DBUtils.SHOPMALL_TITLE));
                String price = cursor.getString(cursor.getColumnIndex( DBUtils.SHOPMALL_PRICE ));
                int img = cursor.getInt(cursor.getColumnIndex( "img" ));
                shopInfo.setId(id);
                shopInfo.setShopMallTitle(title);
                shopInfo.setShopMallPrice(price);
                shopInfo.setImg(img);
                list.add(shopInfo);
            }
            cursor.close();
        }
        return list;
    }
}

