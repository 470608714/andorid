package cn.itcast.shopmall.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import cn.itcast.shopmall.R;
import cn.itcast.shopmall.bean.ShopMallBean;


public class ShopMallAdapter extends BaseAdapter {
    private LayoutInflater layoutInflater;
    private List<ShopMallBean> list;
    public ShopMallAdapter(Context context, List<ShopMallBean> list){
        this.layoutInflater=LayoutInflater.from(context);
        this.list=list;
    }
    @Override
    public  int getCount(){
        return list==null ? 0 : list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }
    @Override
    public long getItemId(int position){
        return  position;
    }
    //重写getView方法，通过inflate()方法加载Item界面的布局文件，获取数据到对应的控件上
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder  vHolder;
        //判断是否为null
        if(convertView==null){
            convertView=layoutInflater.inflate(R.layout.shopmalllist_item,null);
            vHolder=new ViewHolder(convertView);
            convertView.setTag(vHolder);
        }else {
            vHolder=(ViewHolder) convertView.getTag();
        }
        ShopMallBean ShopMallInfo = (ShopMallBean) getItem(position);
        vHolder.tvShopMallTitle.setText(ShopMallInfo.getShopMallTitle());
        vHolder.tvShopMallPrice.setText(ShopMallInfo.getShopMallPrice());
        vHolder.ivImg.setBackgroundResource(ShopMallInfo.getImg());
        return convertView;
    }
    //通过setText方法将该对象添加到convertView中进行缓存
    class ViewHolder{
        TextView tvShopMallTitle;
        TextView tvShopMallPrice;
        ImageView ivImg;
        public ViewHolder(View view){
            tvShopMallTitle=(TextView) view.findViewById(R.id.item_title);
            tvShopMallPrice=(TextView) view.findViewById(R.id.item_price);
            ivImg = view.findViewById(R.id.item_img);
        }
    }
}
