package cn.itcast.shopmall.bean;

public class ShopMallBean {
    private String id;
    private String ShopMallTitle;
    private String ShopMallPrice;
    private  int img;

    public void setImg(int img) {
        this.img = img;
    }

    public int getImg() {
        return img;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getShopMallTitle() {
        return ShopMallTitle;
    }

    public void setShopMallTitle(String shopmallTitle) {
        this.ShopMallTitle = shopmallTitle;
    }

    public String getShopMallPrice() {
        return ShopMallPrice;
    }

    public void setShopMallPrice(String shopmallPrice) {
        this.ShopMallPrice = shopmallPrice;
    }
}